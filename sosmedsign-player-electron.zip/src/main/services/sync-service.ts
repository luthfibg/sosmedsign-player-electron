import { basename } from 'path'
import { OFFLINE_GRACE_VALIDATION_FAILURES, SYNC_INTERVAL_MS } from '../config'
import type { PlaylistStore, StoredPlaylist } from '../db/playlist-store'
import type { ApiClient } from './api-client'
import type { PlaylistItemDto, PlaylistResponse } from './api-types'
import type { CacheManager, DownloadResult } from './cache-manager'
import type { CredentialStore } from './credential-store'
import type { DeviceService, RegistrationClearedReason } from './device-service'
import type { Diagnostics } from './diagnostics'
import { isPlaylistItem, toNewItem } from './playlist-mapper'

export type SyncOutcome =
  | 'applied'
  | 'not-modified'
  | 'no-playlist'
  | 'offline'
  | 'not-registered'
  | 'validation-grace'
  | 'auth-rejected'
  | 'released'
  | 'download-failed'
  | 'error'
  | 'busy'
  | 'aborted'

/** Penghitung masa tenggang disimpan di database supaya tidak hilang saat restart (MiniPC sering dimatikan). */
const K_VALIDATION_FAILURES = 'validation_failures'
const K_AUTH_FAILURES = 'auth_failures'

interface SyncServiceOptions {
  intervalMs?: number
  isOnline?: () => boolean
  /** Jumlah kegagalan beruntun sebelum device dianggap dilepas (default 120, sekitar 6 jam). */
  graceFailures?: number
}

type Listener = () => void

/** Polling dan mirror-sync playlist; semua pekerjaan cache/DB berjalan di main process. */
export class SyncService {
  private timer: NodeJS.Timeout | null = null
  private syncInProgress = false
  /** Naik setiap data lokal dihapus (release/reset); sync yang sedang berjalan membuang hasilnya. */
  private generation = 0
  private readonly intervalMs: number
  private readonly isOnline: () => boolean
  private readonly graceFailures: number
  private readonly listeners = new Set<Listener>()

  constructor(
    private readonly store: PlaylistStore,
    private readonly api: Pick<ApiClient, 'playlist' | 'postSyncLog'>,
    private readonly device: Pick<DeviceService, 'validateRegistration' | 'forgetRegistration'>,
    private readonly credentials: Pick<
      CredentialStore,
      'isRegistered' | 'getOrCreateDeviceCode' | 'load'
    >,
    private readonly cache: CacheManager,
    private readonly diagnostics: Pick<Diagnostics, 'log'>,
    options: SyncServiceOptions = {}
  ) {
    this.intervalMs = options.intervalMs ?? SYNC_INTERVAL_MS
    this.isOnline = options.isOnline ?? (() => true)
    this.graceFailures = options.graceFailures ?? OFFLINE_GRACE_VALIDATION_FAILURES
  }

  start(): void {
    if (this.timer || !this.credentials.isRegistered()) return
    void this.syncOnce()
    this.timer = setInterval(() => void this.syncOnce(), this.intervalMs)
    this.timer.unref?.()
  }

  stop(): void {
    if (!this.timer) return
    clearInterval(this.timer)
    this.timer = null
  }

  async close(): Promise<void> {
    this.stop()
    await this.cache.close()
  }

  /** Dipanggil saat playlist aktif berubah (playlist baru, item pulih dari FAILED, atau data dihapus). */
  onPlaylistChanged(listener: Listener): () => void {
    this.listeners.add(listener)
    return () => {
      this.listeners.delete(listener)
    }
  }

  /**
   * Dihubungkan ke DeviceService.onRegistrationCleared. Selalu menghentikan sync dan mereset penghitung;
   * playlist + cache hanya dihapus untuk alasan selain 'credentials-invalid'. Antrean playback sengaja dipertahankan.
   */
  handleRegistrationCleared(reason: RegistrationClearedReason): void {
    this.stop()
    this.store.deleteState(K_VALIDATION_FAILURES)
    this.store.deleteState(K_AUTH_FAILURES)
    if (reason === 'credentials-invalid') return

    this.generation++
    try {
      this.store.clearPlaylists()
    } catch (error) {
      this.diagnostics.log(`Gagal menghapus playlist lokal: ${errorMessage(error)}`)
    }
    this.cache.clear()
    this.diagnostics.log('Cache konten dan playlist lokal dihapus')
    this.emitPlaylistChanged()
  }

  async syncOnce(forceRefresh = false): Promise<SyncOutcome> {
    if (this.syncInProgress) return 'busy'
    this.cache.retryPendingDeletes()
    if (!this.credentials.isRegistered()) return 'not-registered'
    if (!this.isOnline()) return 'offline'

    this.syncInProgress = true
    const generation = this.generation
    try {
      return await this.runCycle(generation, forceRefresh)
    } catch (error) {
      this.diagnostics.log(`Sync gagal: ${errorMessage(error)}`)
      return 'error'
    } finally {
      this.syncInProgress = false
    }
  }

  private async runCycle(generation: number, forceRefresh: boolean): Promise<SyncOutcome> {
    // 1. Masih terdaftar? Hanya jawaban pasti "pending" dari server yang dihitung menuju pelepasan.
    //    Server tak terjangkau / respons bukan JSON API = tidak tahu, bukan "dilepas" (tidak dihitung).
    const validation = await this.device.validateRegistration()
    if (generation !== this.generation) return 'aborted'
    if (validation.kind === 'registered') {
      this.store.deleteState(K_VALIDATION_FAILURES)
    } else if (validation.kind === 'pending') {
      const n = this.bump(K_VALIDATION_FAILURES)
      this.diagnostics.log(
        `Server menyatakan device belum/tidak terdaftar (${n}/${this.graceFailures})`
      )
      if (n >= this.graceFailures) {
        this.device.forgetRegistration('unregistered', 'dilepas dari CMS (melewati masa tenggang)')
        return 'released'
      }
      return 'validation-grace'
    } else {
      this.diagnostics.log(
        `Validasi registrasi tidak tersedia (${validation.reason}); sync dilewati`
      )
      return 'validation-grace'
    }

    // 2. Ambil playlist
    const deviceCode = this.credentials.getOrCreateDeviceCode()
    const token = this.credentials.load()?.apiToken
    if (!token) return 'not-registered'
    const currentVersion = forceRefresh ? null : this.store.getActiveVersion()

    const response = await this.api.playlist(deviceCode, token, currentVersion)
    if (generation !== this.generation) return 'aborted'

    if (response.status === 204) {
      this.store.deleteState(K_AUTH_FAILURES)
      return this.afterNotModified(generation)
    }
    if (response.status === 404 && response.isApiMessage) {
      this.store.deleteState(K_AUTH_FAILURES)
      return 'no-playlist'
    }
    if ([401, 403].includes(response.status) && response.isApiMessage) {
      return this.noteAuthRejected(`playlist HTTP ${response.status}`)
    }
    // Respons lain (termasuk 401/403/404 berbentuk HTML dari proxy/captive portal) tidak dipercaya.
    if (response.status !== 200 || !isPlaylistResponse(response.json)) {
      this.diagnostics.log(`Sync playlist gagal: respons HTTP ${response.status} tidak valid`)
      return 'error'
    }
    this.store.deleteState(K_AUTH_FAILURES)
    return this.applyPlaylist(response.json, deviceCode, token, generation)
  }

  // ---- playlist baru ----

  private async applyPlaylist(
    response: PlaylistResponse,
    deviceCode: string,
    token: string,
    generation: number
  ): Promise<SyncOutcome> {
    const items = response.playlist.filter(isPlaylistItem)
    if (items.length < response.playlist.length) {
      this.diagnostics.log(
        `Sync: ${response.playlist.length - items.length} item tidak valid dilewati`
      )
    }
    if (items.length === 0 && response.playlist.length > 0) {
      // Server mengirim item tapi semuanya rusak: jangan mengosongkan playlist karena data yang salah.
      this.diagnostics.log('Sync playlist diabaikan: tidak ada item yang valid')
      return 'error'
    }

    // Konten yang sama di beberapa slot diunduh sekali.
    const downloads = new Map<string, DownloadResult>()
    const prepared: { dto: PlaylistItemDto; download: DownloadResult }[] = []
    let bytesDownloaded = 0
    for (const dto of items) {
      const key = `${dto.content_id}\0${dto.content_url}`
      let download = downloads.get(key)
      if (!download) {
        try {
          download = await this.cache.download(dto)
        } catch (error) {
          download = failedDownload(errorMessage(error))
        }
        downloads.set(key, download)
        bytesDownloaded += download.bytesDownloaded
        if (generation !== this.generation) break
        if (download.released) return this.noteAuthRejected('download konten ditolak')
        if (!download.ok) {
          this.diagnostics.log(
            `Konten ${dto.content_id} gagal diunduh: ${download.error ?? 'kesalahan tidak diketahui'}`
          )
        }
      }
      prepared.push({ dto, download })
    }

    if (generation !== this.generation) {
      // Device dilepas/direset saat unduhan berjalan: buang hasilnya, jangan menghidupkan kembali data yang sudah dihapus.
      this.cache.clear()
      this.diagnostics.log('Sync dibatalkan: device dilepas saat unduhan berjalan')
      return 'aborted'
    }

    const readyCount = prepared.filter(({ download }) => download.ok).length
    if (prepared.length > 0 && readyCount === 0) {
      await this.postSyncLog(deviceCode, token, response.version_hash, 'failed', bytesDownloaded)
      return 'download-failed'
    }

    // File playlist lama ditandai "terakhir dipakai sekarang" sebelum diganti, supaya masa tenggang file yatim
    // dihitung dari saat playlist berganti (bukan dari saat terakhir online, yang bisa berhari-hari lalu).
    this.cache.touch(this.pathsOf(this.store.getActivePlaylist()))

    const stored = this.store.activatePlaylist(
      {
        versionHash: response.version_hash,
        generatedAt: response.generated_at,
        slotDurationSeconds: response.slot_duration_seconds
      },
      prepared.map(({ dto, download }) =>
        download.ok && download.path
          ? toNewItem(dto, basename(download.path), 'READY')
          : toNewItem(dto, null, 'FAILED')
      )
    )
    const referenced = this.pathsOf(stored)
    this.cache.touch(referenced)
    this.cache.cleanupUnused(referenced)
    this.emitPlaylistChanged()

    const status = readyCount < prepared.length ? 'partial' : 'success'
    await this.postSyncLog(deviceCode, token, response.version_hash, status, bytesDownloaded)
    this.diagnostics.log(
      `Playlist ${response.version_hash.slice(0, 12)} aktif (${readyCount}/${prepared.length} konten siap, ${bytesDownloaded} byte)`
    )
    return 'applied'
  }

  // ---- tidak ada perubahan ----

  private async afterNotModified(generation: number): Promise<SyncOutcome> {
    const active = this.store.getActivePlaylist()
    if (!active) return 'not-modified'

    const referenced = new Set(this.pathsOf(active))
    this.cache.touch(referenced)

    let recovered = 0
    const attempted = new Map<string, DownloadResult>()
    for (const item of active.items) {
      if (item.downloadStatus !== 'FAILED') continue
      const key = `${item.contentId}\0${item.contentUrl}`
      let result = attempted.get(key)
      if (!result) {
        result = await this.cache.download(toDto(item))
        attempted.set(key, result)
        if (generation !== this.generation) {
          this.cache.clear()
          return 'aborted'
        }
        if (result.released) return this.noteAuthRejected('retry download konten ditolak')
      }
      if (result.ok && result.path) {
        this.store.updateItem(item.id, {
          localFile: basename(result.path),
          downloadStatus: 'READY'
        })
        referenced.add(result.path)
        recovered++
      }
    }

    // Sweep juga di siklus tanpa perubahan: file yatim baru terhapus setelah masa tenggang lewat.
    this.cache.cleanupUnused(referenced)
    if (recovered > 0) {
      this.diagnostics.log(`${recovered} konten gagal berhasil diunduh ulang`)
      this.emitPlaylistChanged()
    }
    return 'not-modified'
  }

  // ---- bantu ----

  /**
   * Token ditolak server (401/403 berbentuk JSON API). Dihitung lewat masa tenggang yang sama dengan validasi
   * registrasi dan TIDAK menghapus data: setelah token diterbitkan ulang (kode reissue), konten yang sudah
   * diunduh tetap dipakai.
   */
  private noteAuthRejected(source: string): SyncOutcome {
    const n = this.bump(K_AUTH_FAILURES)
    this.diagnostics.log(`Token ditolak server (${n}/${this.graceFailures}): ${source}`)
    if (n >= this.graceFailures) {
      this.device.forgetRegistration('credentials-invalid', 'token ditolak server berulang kali')
      return 'released'
    }
    return 'auth-rejected'
  }

  private async postSyncLog(
    deviceCode: string,
    token: string,
    version: string,
    status: 'success' | 'failed' | 'partial',
    bytesDownloaded: number
  ): Promise<void> {
    try {
      const response = await this.api.postSyncLog(deviceCode, token, {
        playlist_version_hash: version,
        status,
        bytes_downloaded: bytesDownloaded
      })
      if ([401, 403].includes(response.status) && response.isApiMessage) {
        this.noteAuthRejected(`sync-log HTTP ${response.status}`)
      } else if (response.status < 200 || response.status >= 300) {
        this.diagnostics.log(`Sync-log gagal: HTTP ${response.status}`)
      }
    } catch (error) {
      // Gagal mengirim sync-log tidak boleh mengganggu playback.
      this.diagnostics.log(`Sync-log gagal dikirim: ${errorMessage(error)}`)
    }
  }

  private pathsOf(playlist: StoredPlaylist | null): string[] {
    return (playlist?.items ?? [])
      .filter((item) => item.localFile)
      .map((item) => this.cache.pathFor(basename(item.localFile as string)))
  }

  private bump(key: string): number {
    const current = Number(this.store.getState(key))
    const next = (Number.isFinite(current) && current > 0 ? Math.trunc(current) : 0) + 1
    this.store.setState(key, String(next))
    return next
  }

  private emitPlaylistChanged(): void {
    for (const listener of this.listeners) listener()
  }
}

function toDto(item: StoredPlaylist['items'][number]): PlaylistItemDto {
  return {
    slot_number: item.slotNumber,
    slots_used: item.slotsUsed,
    content_id: item.contentId,
    content_label: item.contentLabel,
    content_url: item.contentUrl,
    media_type: item.mediaType,
    duration_seconds: item.durationSeconds,
    file_size: item.fileSize,
    checksum_sha256: item.checksumSha256
  }
}

function failedDownload(error: string): DownloadResult {
  return { ok: false, path: null, bytesDownloaded: 0, released: false, error }
}

/** Snapshot kosong (`playlist: []`) valid: artinya semua booking berakhir/dihapus (mirror sync mengosongkan konten). */
function isPlaylistResponse(value: unknown): value is PlaylistResponse {
  if (!value || typeof value !== 'object') return false
  const response = value as Partial<PlaylistResponse>
  return (
    typeof response.version_hash === 'string' &&
    response.version_hash.length > 0 &&
    typeof response.generated_at === 'string' &&
    Number.isFinite(response.slot_duration_seconds) &&
    Array.isArray(response.playlist)
  )
}

function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}
