export {}

/**
 * Tipe API yang diekspos preload ke renderer (window.api). Dideklarasikan global supaya bisa
 * dipakai bersama oleh main, preload, dan renderer tanpa mengubah tsconfig.
 */
declare global {
  interface DeviceStateDto {
    registered: boolean
    /** UUID permanen perangkat (bukan rahasia). */
    deviceCode: string
    venueId: number | null
    deviceName: string | null
  }

  interface PlayerScheduleDto {
    /** CSV hari: "mon,tue,wed". */
    days: string | null
    /** "HH:mm" atau "HH:mm:ss". */
    start: string | null
    end: string | null
    timezone: string | null
    /** "YYYY-MM-DD". */
    startDate: string | null
    endDate: string | null
  }

  interface PlayerItemDto {
    id: number
    contentId: number
    label: string
    mediaType: 'video' | 'image'
    durationSeconds: number
    /** URL sosmedsign-media://media/<file>; hanya item yang file cache-nya siap yang dikirim. */
    mediaUrl: string
    schedule: PlayerScheduleDto | null
  }

  interface PlayerPlaylistDto {
    versionHash: string
    slotDurationSeconds: number
    items: PlayerItemDto[]
  }

  type ActivationResultDto = { ok: true } | { ok: false; message: string }

  interface PlayerApi {
    getDeviceState(): Promise<DeviceStateDto>
    activate(activationCode: string): Promise<ActivationResultDto>
    resetIdentity(): Promise<void>
    getDiagnostics(): Promise<string[]>
    /** Playlist yang siap diputar; null kalau belum pernah ada playlist dari server. */
    getPlaylist(): Promise<PlayerPlaylistDto | null>
    /** Mengirim satu baris log pemutar ke log diagnostik main process. */
    logPlayer(message: string): Promise<void>
    onPlaylistChanged(callback: (playlist: PlayerPlaylistDto | null) => void): () => void
    /** Mengembalikan fungsi untuk berhenti berlangganan. */
    onDeviceStateChanged(callback: (state: DeviceStateDto) => void): () => void
  }

  interface Window {
    api: PlayerApi
  }
}
